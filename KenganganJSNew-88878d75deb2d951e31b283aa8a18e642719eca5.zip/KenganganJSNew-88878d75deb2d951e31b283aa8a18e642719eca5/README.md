# BotAlphatJS
Bot Kicker And Bot Anti Kicker, Check Sider.
------
-

Cara Install Bot AlphatJS :
------
- `pkg install nodejs -y`
- `pkg install git -y`
- `git clone https://github.com/Nadyatjia/AlphatJS`
- `pkg install nano`
- `cd AlphatJS`
- `npm install`
- `npm start`

Cara Menjalankan Bot Kembali :
------
- `cd AlphatJS`
- `npm start`

Command "Help" :
------
           🎶 Keyword Khusus Admin 🎶
           - `[Kick On/Off] = On/Off Mode Kick`
           - `[Kickall] = Mengekick Semua Member`
           - `[Info kick] = Cara Menggunakan Fitur Kickall`
           - `[Cancel On/Off] = On/Off Mode Cancel`
           - `[Cancelall] = Membatalkan Semua Invite'an`
           - `[Qrp On/Off]= On/Off Link Group`

           🎶 Keyword Dalam Group 🎶
           - `[Chucky keluar] = Mengusir Bot Dari Group`
           - `[Status] = Menampilkan Info Kick&Cancel`
           - `[Speed] = Ngetest Respons Bot`
           - `[Left NamaGroup] = Bot Keluar Dari Group`
           - `[Setpoint/Set] = Untuk Memulai Sider`
           - `[Recheck/Check] = Melihat List Yang Sider`
           - `[Clear/Reset] = Untuk Hapus List Sider`
           - `[Myid] = Untuk Mengetahui MID`
           - `[Ig Ursname Kamu] = Info Instagram Kamu`
           - `[Qr Open/Close] = Buka/Tutup Link Group`
           - `[spam (S Huruf Kecil)] = Bot Akan Spam`
           - `[List admin] = Melihat Daftar Admin`
           - `[Tag all] = Mengetag Semua Member`
           - `[Creator] = Owner Pembuat Bot`
           - `[Gift] = Sent Sticker`

Credit By@ Nadya Sutjiadi.
------
- `Follow My Instagram : nadya.tjia`
- `Add My ID LINE : nad_nad. (pake titik)`

Thx To :
------
- `Alfatdirk And LINE-TCR TEAM`


